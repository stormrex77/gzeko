


 const element = document.getElementById("coup");
 element.addEventListener("click", myFunction);

 function myFunction () {
     const box =  document.getElementById("box")
     box.style.display = "flex"
    document.getElementById("taxes-box").style.display = "none"
    document.getElementById("vouchbox").style.display = "none"

 }

 const vouch = document.getElementById("vouch")

 vouch.addEventListener("click", function () {
    document.getElementById("taxes-box").style.display = "none"
    box.style.display = "none"
    document.getElementById("vouchbox").style.display = "flex"
 })

 const taxes = document.getElementById("taxes")

 taxes.addEventListener ("click", function () {
     document.getElementById("taxes-box").style.display = "block"
    document.getElementById("vouchbox").style.display = "none"
    document.getElementById("box").style.display = "none"

 })